﻿namespace MTE
{
    public struct GrassGenerationSettings
    {
        public bool UseStaticBatch { get; set; }
        public bool HideGrassObjectInEditor { get; set; }
    }
}